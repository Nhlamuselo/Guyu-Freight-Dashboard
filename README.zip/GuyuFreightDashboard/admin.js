// admin.js

const token = "patZGOKtFTt0mt4e4.86343c836aa999de8d639476739b599961d4d98bb139107e28285bacdff61b11"; 
const baseId = "appxtqIXMFD8nuPtg";
const tableName = "Freight Booking Dashboard";

const endpoint = `https://api.airtable.com/v0/${baseId}/${tableName}`;

// Load records
fetch(endpoint, {
  headers: {
    Authorization: `Bearer ${token}`,
    "Content-Type": "application/json"
  }
})
  .then(res => res.json())
  .then(data => {
    const tableBody = document.querySelector("#bookingsTable tbody");

    data.records.forEach(record => {
      const fields = record.fields;
      const recordId = record.id;

      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${fields["Pickup Location"] || ""}</td>
        <td>${fields["Delivery Location"] || ""}</td>
        <td>${fields["Date"] || ""}</td>
        <td>${fields["Vehicle Type"] || ""}</td>
        <td>${fields["Type of Goods"] || ""}</td>
        <td>${fields["Weight"] || ""}</td>
        <td>${fields["Instructions"] || ""}</td>
        <td>${fields["Contact Info"] || ""}</td>
        <td>R${fields["Estimated Price"] || "0.00"}</td>
        <td class="${getStatusClass(fields["Status"])}">${fields["Status"] || "New"}</td>
        <td>
          <button onclick="updateStatus('${recordId}', 'In Progress')">⏳</button>
          <button onclick="updateStatus('${recordId}', 'Done')">✅</button>
          <button onclick="deleteRecord('${recordId}')">🗑</button>
        </td>
      `;

      tableBody.appendChild(row);
    });
  })
  .catch(err => {
    console.error("Error loading bookings:", err);
  });

// Helpers
function getStatusClass(status) {
  if (!status) return "status-new";
  const lower = status.toLowerCase();
  if (lower === "in progress") return "status-in-progress";
  if (lower === "done") return "status-done";
  return "status-new";
}

function updateStatus(id, newStatus) {
  fetch(`https://api.airtable.com/v0/${baseId}/${tableName}/${id}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      fields: {
        Status: newStatus
      }
    })
  })
    .then(res => res.json())
    .then(() => {
      alert(`Status updated to ${newStatus}`);
      location.reload(); // refresh the page to reflect changes
    })
    .catch(err => console.error("Status update failed:", err));
}

function deleteRecord(id) {
  if (!confirm("Are you sure you want to delete this record?")) return;

  fetch(`https://api.airtable.com/v0/${baseId}/${tableName}/${id}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`
    }
  })
    .then(res => res.json())
    .then(() => {
      alert("Booking deleted");
      location.reload(); // refresh page
    })
    .catch(err => console.error("Delete failed:", err));
}


