// Google Maps Autocomplete Initialization
function initAutocomplete() {
  const pickupInput = document.getElementById("pickup");
  const deliveryInput = document.getElementById("delivery");

  new google.maps.places.Autocomplete(pickupInput);
  new google.maps.places.Autocomplete(deliveryInput);
}

// Form Validation
document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {
    const pickup = document.getElementById("pickup").value.trim();
    const delivery = document.getElementById("delivery").value.trim();
    const date = document.getElementById("date").value;
    const vehicle = document.getElementById("vehicle").value;
    const goods = document.getElementById("goods").value.trim();
    const weight = document.getElementById("weight").value.trim();
    const contact = document.getElementById("contact").value.trim();

    if (!pickup || !delivery || !date || !vehicle || !goods || !contact) {
      alert("Please fill in all required fields.");
      e.preventDefault();
      return;
    }

    const phonePattern = /^[0-9\-\+\s\(\)]{7,15}$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!phonePattern.test(contact) && !emailPattern.test(contact)) {
      alert("Please enter a valid phone number or email address.");
      e.preventDefault();
      return;
    }
  });
});
// Price Estimator Logic
function estimatePrice() {
  const vehicle = document.getElementById("vehicle").value;
  const weight = parseFloat(document.getElementById("weight").value);
  const priceField = document.getElementById("price");

  let basePrice = 0;
  let ratePerKg = 0;

  switch (vehicle) {
    case "bakkie":
      basePrice = 300;
      ratePerKg = 2;
      break;
    case "1-ton":
      basePrice = 500;
      ratePerKg = 3;
      break;
    case "8-ton":
      basePrice = 800;
      ratePerKg = 4;
      break;
    case "flatbed":
      basePrice = 1000;
      ratePerKg = 5;
      break;
    case "refrigerated":
      basePrice = 1200;
      ratePerKg = 6;
      break;
    default:
      priceField.value = "";
      return;
  }

  if (!isNaN(weight)) {
    const total = basePrice + ratePerKg * weight;
    priceField.value = `R${total.toFixed(2)}`;
  } else {
    priceField.value = "";
  }
}

// Trigger price calculation when vehicle or weight changes
document.getElementById("vehicle").addEventListener("change", estimatePrice);
document.getElementById("weight").addEventListener("input", estimatePrice);

